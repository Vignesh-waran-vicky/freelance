package com.aca.aem.core.utils;

import org.apache.sling.api.resource.ResourceResolver;

public interface ResourceService {
    public ResourceResolver getResourceResolver();
}
