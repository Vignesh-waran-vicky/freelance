package com.shimano.bike.dealer.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.wcm.core.components.models.contentfragment.ContentFragmentList;
import com.adobe.cq.wcm.core.components.models.contentfragment.DAMContentFragment;
import com.day.cq.dam.api.Asset;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.drew.lang.annotations.NotNull;
import com.google.common.base.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.via.ResourceSuperType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;
import java.lang.reflect.Array;

@Model(adaptables = SlingHttpServletRequest.class, adapters = {ContentFragmentList.class, ComponentExporter.class},
        resourceType = "shimano-dealer/components/contentfragmenttaglist")

public class ContentFragmentCustomModel implements ContentFragmentList{

    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    String testName = StringUtils.EMPTY;

    @Self
    @Via(type = ResourceSuperType.class)
    private ContentFragmentList ContentFragmentList;

    @SlingObject
    private ResourceResolver resourceResolver;

    private HashSet tagSet;
    private List<String> tagIds;

    public String getTagName() {
        try{
            if (Optional.fromNullable(ContentFragmentList).isPresent()){
                tagSet = new HashSet<>();
                Collection<DAMContentFragment> listItems = ContentFragmentList.getListItems();
                Iterator<DAMContentFragment> iterator = listItems.iterator();
                while(iterator.hasNext()) {
                    DAMContentFragment next = iterator.next();
                    String editorJSON = next.getEditorJSON();
                    JSONObject jsonObject = new JSONObject(editorJSON);
                    String path = jsonObject.getString("path");

                    Asset asset = resourceResolver.resolve(path).adaptTo(Asset.class);
                    Object tagObject = asset.getMetadata().get("cq:tags");
                    log.info("Vignesh" +tagObject);

                    /*Resource resource = (Resource) tagObject;*/
                    /*TagManager tm = resourceResolver.adaptTo(TagManager.class);

                     tagIds = new ArrayList<String>();


                    for (Tag tag : tm.getTags(resource)) {
                        tagIds.add(tag.getTitle());
                    }*/

                }
                testName = "success";

            }
        }catch (JSONException e) {
            e.printStackTrace();
        }
        return testName;
    }

    @Override
    public @NotNull Collection<DAMContentFragment> getListItems() {
        return ContentFragmentList.getListItems();
    }
    @Override
    public @NotNull
    String getExportedType() {
        return ContentFragmentList.getExportedType();
    }
}
